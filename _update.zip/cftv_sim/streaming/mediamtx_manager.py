"""Gera o mediamtx.yml e controla o processo MediaMTX (somente loopback)."""
from __future__ import annotations

import logging
import subprocess
import time
from pathlib import Path
from typing import Optional

from core import config
from core.ports import is_port_free

log = logging.getLogger(__name__)


def render_config(rtsp: int, webrtc: int, hls: int, api: int) -> str:
    return f"""# Gerado automaticamente por cftv_sim - nao edite
logLevel: warn
rtsp: yes
rtspAddress: 127.0.0.1:{rtsp}
rtspTransports: [tcp]
rtmp: no
srt: no
webrtc: yes
webrtcAddress: 127.0.0.1:{webrtc}
webrtcAllowOrigin: '*'
webrtcLocalUDPAddress: 127.0.0.1:8189
hls: yes
hlsAddress: 127.0.0.1:{hls}
hlsAllowOrigin: '*'
hlsAlwaysRemux: yes
hlsVariant: lowLatency
api: yes
apiAddress: 127.0.0.1:{api}
metrics: no
pprof: no
playback: no
authMethod: internal
authInternalUsers:
  - user: any
    ips: ['127.0.0.1', '::1']
    permissions:
      - action: publish
      - action: read
      - action: api
paths:
  all_others:
"""


class MediaMtxManager:
    def __init__(self, ports: dict, workdir: Path | None = None) -> None:
        self.rtsp = int(ports.get("mediamtx_rtsp_internal", 18554))
        self.webrtc = int(ports.get("mediamtx_webrtc", 8889))
        self.hls = int(ports.get("mediamtx_hls", 8888))
        self.api = int(ports.get("mediamtx_api", 9997))
        self.workdir = workdir or (config.DATA_DIR / "mediamtx")
        self.proc: Optional[subprocess.Popen] = None
        self.error = ""

    @property
    def available(self) -> bool:
        return config.bin_path("mediamtx") is not None

    def start(self) -> bool:
        exe = config.bin_path("mediamtx")
        if not exe:
            self.error = "mediamtx nao encontrado (rode tools/fetch_binaries.py)"
            return False
        self.workdir.mkdir(parents=True, exist_ok=True)
        cfg = self.workdir / "mediamtx.yml"
        cfg.write_text(render_config(self.rtsp, self.webrtc, self.hls, self.api), encoding="utf-8")
        self.proc = subprocess.Popen([str(exe), str(cfg)], stdout=open(config.LOG_DIR / "mediamtx.log", "ab"),
                                     stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            if self.proc.poll() is not None:
                self.error = f"mediamtx encerrou (codigo {self.proc.returncode}); veja logs/mediamtx.log"
                return False
            if not is_port_free(self.rtsp, "127.0.0.1"):
                return True
            time.sleep(0.2)
        self.error = "mediamtx nao abriu a porta RTSP interna"
        return False

    def stop(self) -> None:
        p, self.proc = self.proc, None
        if p:
            p.terminate()
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                p.kill()

    @property
    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

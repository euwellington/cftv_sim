"""Barra fixa com as URLs HTTP e RTSP reais (usuario e senha) prontas para copiar."""
from __future__ import annotations

from PyQt6.QtCore import QTimer
from PyQt6.QtGui import QGuiApplication
from PyQt6.QtWidgets import QComboBox, QFrame, QGridLayout, QLabel, QLineEdit, QPushButton


class EndpointBar(QFrame):
    def __init__(self, ctx) -> None:  # noqa: ANN001
        super().__init__()
        self.ctx = ctx
        self.setObjectName("Header")
        self.rows = ctx.access_rows()
        g = QGridLayout(self)
        g.setContentsMargins(20, 6, 20, 6)
        g.setHorizontalSpacing(8)
        g.setVerticalSpacing(4)
        self.combo = QComboBox()
        self.combo.addItems([r["label"] for r in self.rows])
        self.combo.currentIndexChanged.connect(self._fill)
        self.http = self._line()
        self.rtsp = self._line()
        self.portal = self._line()
        g.addWidget(QLabel("Equipamento:"), 0, 0)
        g.addWidget(self.combo, 0, 1)
        self.creds = QLabel("")
        self.creds.setObjectName("Muted")
        g.addWidget(self.creds, 0, 2, 1, 2)
        for i, (lbl, w) in enumerate((("HTTP", self.http), ("RTSP", self.rtsp), ("Portal", self.portal)), start=1):
            g.addWidget(QLabel(lbl + ":"), i, 0)
            g.addWidget(w, i, 1, 1, 2)
            b = QPushButton("Copiar")
            b.setFixedWidth(80)
            b.clicked.connect(lambda _=False, ww=w, bb=b: self._copy(ww, bb))
            g.addWidget(b, i, 3)
        g.setColumnStretch(2, 1)
        self._fill()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._fill)
        self._timer.start(5000)  # acompanha mudanca de IP/URL publica

    @staticmethod
    def _line() -> QLineEdit:
        e = QLineEdit()
        e.setReadOnly(True)
        e.setStyleSheet("font-family: Consolas, 'DejaVu Sans Mono', monospace;")
        return e

    def _fill(self) -> None:
        self.rows = self.ctx.access_rows()
        i = max(0, self.combo.currentIndex())
        if i >= len(self.rows):
            return
        r = self.rows[i]
        self.http.setText(r["http"])
        self.rtsp.setText(r["rtsp"])
        from core import urls
        self.portal.setText(urls.portal_url(self.ctx.host(), self.ctx.profile.web_port, self.ctx.admin_user,
                                            self.ctx.admin_password or "<senha>"))
        pw = self.ctx.admin_password or "(senha nao informada)"
        self.creds.setText(f"Usuario: {self.ctx.admin_user}   Senha: {pw}")

    def _copy(self, w: QLineEdit, b: QPushButton) -> None:
        QGuiApplication.clipboard().setText(w.text())
        b.setText("Copiado!")
        QTimer.singleShot(1200, lambda: b.setText("Copiar"))

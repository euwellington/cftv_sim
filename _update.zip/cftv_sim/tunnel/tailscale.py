"""Tailscale Funnel: ``tailscale funnel --bg PORTA`` e URL ``https://<maquina>.<tailnet>.ts.net``."""
from __future__ import annotations

import json
import os
import subprocess

from .base import TunnelError, TunnelProvider


class TailscaleTunnel(TunnelProvider):
    name = "tailscale"
    binary = "tailscale"
    install_hint = ("Instale o Tailscale (https://tailscale.com/download), faça login e habilite o Funnel "
                    "no painel admin (ACL 'funnel').")

    def extra_paths(self) -> list[str]:
        return [r"C:\Program Files\Tailscale\tailscale.exe", "/usr/bin/tailscale", "/usr/local/bin/tailscale",
                "/Applications/Tailscale.app/Contents/MacOS/Tailscale"]

    def _run(self, *args: str, timeout: int = 40) -> subprocess.CompletedProcess:
        exe = self.find_binary()
        self.log_line("$ tailscale " + " ".join(args))
        r = subprocess.run([exe, *args], capture_output=True, text=True, timeout=timeout,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        for ln in (r.stdout + r.stderr).splitlines():
            self.log_line(ln)
        return r

    def start(self) -> str:
        self.status("starting")
        st = self._run("status", "--json", timeout=15)
        if st.returncode != 0:
            raise TunnelError("Tailscale nao esta ativo/logado. Abra o app do Tailscale e conecte.")
        try:
            dns = json.loads(st.stdout)["Self"]["DNSName"].rstrip(".")
        except (KeyError, ValueError) as exc:
            raise TunnelError("nao foi possivel ler o nome DNS do Tailscale (MagicDNS/HTTPS habilitados?)") from exc
        r = self._run("funnel", "--bg", str(self.local_port))
        out = r.stdout + r.stderr
        if r.returncode != 0:
            if "funnel" in out.lower() and ("not enabled" in out.lower() or "https://login.tailscale.com" in out):
                raise TunnelError("Funnel nao habilitado nesta conta. Abra o link mostrado no log para habilitar.")
            raise TunnelError(f"tailscale funnel falhou: {out.strip()[:200]}")
        self.url = f"https://{dns}"
        self.status("running")
        return self.url

    def stop(self) -> None:
        try:
            self._run("funnel", "reset", timeout=15)
        except Exception:  # noqa: BLE001
            pass
        self.url = ""
        self.status("stopped")

"""ngrok: ``ngrok http PORTA`` e leitura da URL pela API local (127.0.0.1:4040)."""
from __future__ import annotations

import json
import urllib.request

from .base import TunnelError, TunnelProvider


class NgrokTunnel(TunnelProvider):
    name = "ngrok"
    binary = "ngrok"
    install_hint = "Instale em https://ngrok.com/download e configure o authtoken."

    def _api_url(self) -> str:
        try:
            with urllib.request.urlopen("http://127.0.0.1:4040/api/tunnels", timeout=1.5) as r:
                for t in json.load(r).get("tunnels", []):
                    if t.get("public_url", "").startswith("https://"):
                        return t["public_url"]
        except Exception:  # noqa: BLE001
            pass
        return ""

    def start(self) -> str:
        exe = self.find_binary()
        self.status("starting")
        cmd = [exe, "http", str(self.local_port), "--log", "stdout"]
        token = self.ctx.profile.public.ngrok_authtoken
        if token:
            cmd += ["--authtoken", token]
        self.proc = self.spawn(cmd)
        self.pump(self.proc)
        try:
            self.url = self.wait_for(self._api_url, 40, "a URL do ngrok (authtoken configurado?)")
        except TunnelError:
            raise
        self.status("running")
        return self.url

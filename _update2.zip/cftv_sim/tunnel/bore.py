"""bore (TCP, sem conta): abre as portas do simulador em ``bore.pub:PORTA`` para sistemas de fora da sua rede.

Um processo ``bore local <porta> --to bore.pub`` por porta (RTSP e HTTP de cada equipamento + portal).
Os enderecos publicos (host:porta) ficam em ``ctx.tcp_endpoints`` e aparecem na barra de URLs
(Endereco > Tunel TCP). O servidor ``bore.pub`` e publico e gratuito: qualquer um que saiba o endereco
alcanca a porta, entao a protecao e a autenticacao Digest + bloqueio por tentativas do simulador.
"""
from __future__ import annotations

import re
import subprocess
import sys
import threading
import time

from core import config

from .base import TunnelError, TunnelProvider

SERVER = "bore.pub"
LISTEN_RE = re.compile(r"listening at\s+([\w.\-]+):(\d+)")


class BoreTunnel(TunnelProvider):
    name = "bore"
    binary = "bore"
    install_hint = "Rode: python tools/fetch_binaries.py --only bore"

    def __init__(self, ctx) -> None:  # noqa: ANN001
        super().__init__(ctx)
        self.procs: list[subprocess.Popen] = []

    def find_binary(self) -> str:
        p = config.bin_path("bore")
        if p:
            return str(p)
        self.log_line("bore nao encontrado: baixando automaticamente...")
        try:
            sys.path.insert(0, str(config.ROOT))
            from tools import fetch_binaries
            fetch_binaries.BIN.mkdir(exist_ok=True)
            fetch_binaries.fetch_bore(False)
        except Exception as exc:  # noqa: BLE001
            raise TunnelError(f"nao foi possivel baixar o bore ({exc}). {self.install_hint}") from exc
        p = config.bin_path("bore")
        if not p:
            raise TunnelError("bore nao encontrado apos o download. " + self.install_hint)
        return str(p)

    def _ports(self) -> list[int]:
        prof = self.ctx.profile
        ports = [d.rtsp_port for d in prof.devices] + [d.http_port for d in prof.devices] + [prof.web_port]
        return list(dict.fromkeys(ports))

    def _open_one(self, exe: str, port: int, out: dict[int, tuple[str, int]]) -> None:
        proc = self.spawn([exe, "local", str(port), "--to", SERVER])
        self.procs.append(proc)

        def on_line(line: str) -> None:
            m = LISTEN_RE.search(line)
            if m:
                out[port] = (m.group(1), int(m.group(2)))
        self.pump(proc, on_line)

    def start(self) -> str:
        exe = self.find_binary()
        self.status("starting")
        eps: dict[int, tuple[str, int]] = {}
        ports = self._ports()
        for p in ports:
            self._open_one(exe, p, eps)
        end = time.monotonic() + 30
        while time.monotonic() < end and len(eps) < len(ports):
            if all(pr.poll() is not None for pr in self.procs):
                break
            time.sleep(0.3)
        if not eps:
            self.stop()
            raise TunnelError(f"nao consegui abrir o tunel em {SERVER} (sem internet ou servidor indisponivel?). Veja o log.")
        self.ctx.tcp_endpoints = eps
        web = eps.get(self.ctx.profile.web_port)
        self.url = f"http://{web[0]}:{web[1]}" if web else f"{SERVER}"
        self.log_line("Enderecos publicos: " + ", ".join(f"{lp} -> {h}:{rp}" for lp, (h, rp) in sorted(eps.items())))
        missing = [p for p in ports if p not in eps]
        if missing:
            self.log_line(f"aviso: sem tunel para as portas {missing}")
        self.status("running")
        return self.url

    def stop(self) -> None:
        for p in self.procs:
            if p.poll() is None:
                p.terminate()
        for p in self.procs:
            try:
                p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                p.kill()
        self.procs.clear()
        self.proc = None
        self.url = ""
        self.ctx.tcp_endpoints = {}
        self.status("stopped")
